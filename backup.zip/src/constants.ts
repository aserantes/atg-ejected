// I got these from the webpage and tested them against the API.
export const allowedTerms = ["V4", "V5", "V64", "V65", "V75", "GS75", "V86"];
